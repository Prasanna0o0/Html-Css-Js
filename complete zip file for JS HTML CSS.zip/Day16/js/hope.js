let arr=[1,2,3,4,5,6,7,8,9,0];
// for (let index = 0; index < arr.length; index++) {
//   console.log(arr[index]);
// }
let op=[0,1,2,3,4,5,"prasanna"];
console.log(op);

// let go= arr.slice(0,3);
// console.log(go);
// //console.log(arr.toString());

// // let iterator=0;
// // while (iterator==IntegerArray[iterator])//checks whether the iterator is equal to the IntegerArray Elements
// // {
    
// //     console.log(`${iterator} exists in array "IntegerArray" `);
// //     console.log("arr : "+IntegerArray[iterator]);
// //     iterator=iterator+1;
// // }
