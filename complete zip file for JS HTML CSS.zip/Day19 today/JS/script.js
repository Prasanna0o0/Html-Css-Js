
var candidates = [];
//  document.getElementById("gridToForm").style.display = "none";
//  document.getElementById("formToGrid").style.display = "none";

 var candidateId="";

//first name validation
function validateFirstName() {
	
	let message = document.getElementById("firstName");
	let error = document.getElementById("firstNameError");
	if (message.value == "") {
		error.innerHTML = "First name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//Accountablity
function Accountablity1() {
	
	let message = document.getElementById("Accountablity");
	let error = document.getElementById("AccountablityError");
	if (message.value == "") {
		error.innerHTML = "Accountablity Group is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//Office
function Office1() {
	
	let message = document.getElementById("Office");
	let error = document.getElementById("OfficeError");
	if (message.value == "") {
		error.innerHTML = "Office is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}

// License
// function License1() {
// 	let message = document.getElementById("License");
// 	var regex = "^[A-Za-z][0-9/\W/]{2,20}$";
//     if (message.value != "") {// Required Field Validation
// 	if (message.value.length == 10 && message.value != regex) { // RegEx Validation    
// 		document.getElementById("LicenseError").innerHTML = "";
// 		return true;
// 	} else {
// 		document.getElementById("LicenseError").innerHTML =
// 			"Enter valid input";
// 		return false;
// 	}
// }
// else{
//     document.getElementById("LicenseError").innerHTML = "License Number  is required";
// 		return false;
// }
// }
//License1
function License1() {
	
	let message = document.getElementById("License");
	let error = document.getElementById("LicenseError");
	if (message.value == "") {
		error.innerHTML = "License is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// group
function group1() {
	
	let message = document.getElementById("group");
	let error = document.getElementById("groupError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}
// sessions
function sessions1() {
	
	let message = document.getElementById("sessions");
	let error = document.getElementById("sessionsError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}
// experience 
function experience1() {
	
	let message = document.getElementById("experience");
	let error = document.getElementById("experienceError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}
// moment 
function moment1() {
	
	let message = document.getElementById("moment");
	let error = document.getElementById("momentError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}
// of 
function of1() {
	
	let message = document.getElementById("of");
	let error = document.getElementById("ofError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}
// objectives
function objectives1() {
	
	let message = document.getElementById("objectives");
	let error = document.getElementById("objectivesError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}

// roadmap
function roadmap1() {
	
	let message = document.getElementById("roadmap");
	let error = document.getElementById("roadmapError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}
// RTT
function RTT1() {
	
	let message = document.getElementById("RTT");
	let error = document.getElementById("RTTError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}
//add
function add1() {
	
	let message = document.getElementById("add");
	let error = document.getElementById("addError");
	if (message.value == "") {
		error.innerHTML = "input value is required !";
		return false;
	} else {
		error.innerHTML = "passs----------------";
		return true;
	}
}

//lastname validation
function validateLastName() {
	let message = document.getElementById("lastName");
	let error = document.getElementById("lastNameError");
	if (message.value == "") {
		error.innerHTML = "Last Name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}


//validating gender
function validateGender() {
	if (
		document.getElementById("male").checked == true ||
		document.getElementById("female").checked == true ||
		document.getElementById("other").checked == true
	) {
		document.getElementById("genderError").innerHTML = "pas----------";
		return true;
	} else {
		document.getElementById("genderError").innerHTML =
			"Please select any one option";
		return false;
	}
}
function validateRate() {
	if (
		document.getElementById("1").checked == true ||
		document.getElementById("2").checked == true ||
		document.getElementById("3").checked == true ||
		document.getElementById("4").checked == true ||
	//	document.getElementById("female").checked == true ||
		document.getElementById("5").checked == true ||
		document.getElementById("6").checked == true ||
		document.getElementById("7").checked == true ||
		document.getElementById("8").checked == true ||
		document.getElementById("9").checked == true ||
		document.getElementById("10").checked == true 
	) {
		document.getElementById("gender1Error").innerHTML = "pas----------";
		return true;
	} else {
		document.getElementById("gender1Error").innerHTML =
			"Please select any one option";
		return false;
	}
}
//email validation
// function validateEmail() {
// 	let message = document.getElementById("e-mail");
// 	let emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
// 	if (message.value != "") {     // Required Field Validation
// 		if (message.value.match(emailFormat)) {  // RegEx Validation
// 			document.getElementById("e-mailError").innerHTML = "";
// 			return true;
// 		} else {
// 			document.getElementById("e-mailError").innerHTML =
// 				"Enter in correct format";
// 			return false;
// 		}
// 	} else {
// 		document.getElementById("e-mailError").innerHTML = "Email ID is required";
// 		return false;
// 	}
// }

function validateNumber() {
	let message = document.getElementById("mobileNumber");
	var regex = "/^[0-9]{10}$/";
    if (message.value != "") {// Required Field Validation
	if (message.value.length == 10 && message.value != regex) { 
		document.getElementById("mobileNumberError").innerHTML = "";
		return true;
	} else {
		document.getElementById("mobileNumberError").innerHTML =
			"Enter valid input";
		return false;
	}
}
else{
    document.getElementById("mobileNumberError").innerHTML = "Mobile Number  is required";
		return false;
}
}

//validating file
// function validateFile() {
// 	let error = document.getElementById("fileError");

	
// 	if (document.getElementById("upload").value == "") {
// 		error.innerHTML = "Please select any file";
// 		return false;
// 	} else {
		

// 		let extn = document.getElementById("upload").value.split(".").pop();
// 		if (
// 			extn.toLowerCase() == "jpg" ||
// 			extn.toLowerCase() == "jpeg" ||
// 			extn.toLowerCase() == "png" ||
// 			extn.toLowerCase() == "pdf" ||
// 			extn.toLowerCase() == "doc" ||
// 			extn.toLowerCase() == "docx"
// 		) {
// 			error.innerHTML = "";
// 			return true;
// 		} else {
// 			error.innerHTML = "Upload a file with Valid format";
// 			return false;
// 		}
// 	}
// }


function strToDate(datestr) {
	let dateArray = datestr.split("-");
	return new Date(dateArray[0], dateArray[1], dateArray[2]);
}

//birthday date validation
function validateJoinedDate() {

	if (document.getElementById("joinedDate").value == "") {
		document.getElementById("joinedDateError").innerHTML =
			"*Birthday date is required";
		return false;
	}
	
	else if (document.getElementById("endDate").value != "") {
		let joinedDate = strToDate(document.getElementById("joinedDate").value);
		let endDate = strToDate(document.getElementById("endDate").value);

		
		if (endDate < joinedDate) {
			document.getElementById("joinedDateError").innerHTML =
				"*birthday date must be less than the End date";
		} else {
			document.getElementById("joinedDateError").innerHTML = "";
			return true;
		}
	}
	
	else {
		document.getElementById("joinedDateError").innerHTML = "";
		return true;
	}
}

//to date validation hire date 
function validateEndDate() {
	
	if (document.getElementById("endDate").value == "") {
		document.getElementById("endDateError").innerHTML = "*Hire date is required";
		return false;
	}
	
	else if (document.getElementById("joinedDate").value != "pas----------") {
		let joinedDate = strToDate(document.getElementById("joinedDate").value);
		let endDate = strToDate(document.getElementById("endDate").value);

		
		if (endDate < joinedDate) {
			document.getElementById("endDateError").innerHTML =
				"*Hire date must be greater than the Joined date";
		} else {
			document.getElementById("endDateError").innerHTML = "";
			return true;
		}
	}
	
	else {
		document.getElementById("endDateError").innerHTML = "";
		return true;
	}
}

//validating verification Checkbox
function verification() {
	let error = document.getElementById("verificationError");
	if (document.getElementById("verification").checked) { //Required Validation
		error.innerHTML = "";
		return true;
	} else {
		error.innerHTML = "Please select ";
		return false;
	}
}
//crew validation
function crew() {
	let error = document.getElementById("crewError");
	if (document.getElementById("crew").value == "select") {
		error.innerHTML = "Please select any option";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}

//Role validation
function Role() {
	let error = document.getElementById("roleError");
	if (document.getElementById("role").value == "select") {
		error.innerHTML = "Please select any option";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// Cell phone number
function cellPhoneNumber() {
	let message = document.getElementById("cell");
	var regex = "/^[0-9]{10}$/";
    if (message.value != "") {// Required Field Validation
	if (message.value.length == 10 && message.value != regex) { 
		document.getElementById("cellError").innerHTML = "";
		return true;
	} else {
		document.getElementById("cellError").innerHTML =
			"Enter valid input";
		return false;
	}
}
else{
    document.getElementById("cellError").innerHTML = "Cell Phone Number  is required !";
		return false;
}
}
// city validation 
function city() {
	
	let message = document.getElementById("city");
	let error = document.getElementById("cityError");
	if (message.value == "") {
		error.innerHTML = "city name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// emergrncy contact number 
function contactNumber() {
	let message = document.getElementById("contactNumber1");
	var regex = "/^[0-9]{10}$/";
    if (message.value != "") {// Required Field Validation
	if (message.value.length == 10 && message.value != regex) { 
		document.getElementById("contactNumberError").innerHTML = "";
		return true;
	} else {
		document.getElementById("contactNumberError").innerHTML =
			"Enter valid input";
		return false;
	}
}
}
// Preferred validation
function Preferred() {
	
	let message = document.getElementById("Preferred");
	let error = document.getElementById("PreferredError");
	if (message.value == "") {
		error.innerHTML = "Preferred name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}

// Experience validation
function Experience() {
	
	let message = document.getElementById("Experience");
	let error = document.getElementById("ExperienceError");
	if (message.value == "") {
		error.innerHTML = "Experience is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//Home validation
function Home() {
	
	let message = document.getElementById("Home");
	let error = document.getElementById("HomeError");
	if (message.value == "") {
		error.innerHTML = "Experience is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// emergency contact name
function contactName() {
	
	let message = document.getElementById("EmergencycontactName");
	let error = document.getElementById("EmergencycontactNameError");
	if (message.value == "") {
		error.innerHTML = "Contact name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//validating all fields to show error messages during submit
function validateForm() {
	var errorCount = 0;
	//debugger
	if (!validateFirstName()) {
		errorCount++;
	}

	if (!Accountablity1()) {
		errorCount++;
	}
	if (!Office1()) {
		errorCount++;
	}
	if (!License1()) {
		errorCount++;
	}
	if (!group1()) {
		errorCount++;
	}
	if (!sessions1()) {
		errorCount++;
	}

	// if (!validateJob()) {
		// errorCount++;
	// }
	if (!experience1()) {
		errorCount++;
	}
	if (!moment1()) {
		errorCount++;
	}
	if (!of1()) {
		errorCount++;
	}
    if (!objectives1()) {
		errorCount++;
	}
    if (!roadmap1()) {
		errorCount++;
	}
	if (!RTT1()) {
		errorCount++;
	}
	if (!add1()) {
		errorCount++;
	}
	if (!validateGender()) {
		errorCount++;
	}
	if (!validateRate()) {
		errorCount++;
	}
	
	if (errorCount > 0) { 
		return false;
	}
	return true;
}
//Submit action for Update and Save operation
//Function to read the candidate information from the form and return the candidate as Json object
function readCandidateInfo() {
	//debugger
	let firstName = document.getElementById("firstName").value;
	let License = document.getElementById("License").value;
	let group = document.getElementById("group").value;

	let sessions = document.getElementById("sessions").value;
	//let group = document.getElementById("group").value;
	//let sessions = document.getElementById("sessions").value;
	let experience = document.getElementById("experience").value;
	let moment = document.getElementById("moment").value;
    let of = document.getElementById("of").value;
    let Accountablity = document.getElementById("Accountablity").value;
    let Office = document.getElementById("Office").value;
   
    let objectives = document.getElementById("objectives").value;
    let roadmap = document.getElementById("roadmap").value;
	let RTT = document.getElementById("RTT").value;
	let add = document.getElementById("add").value;
    let gender = "";
	let gender1 = "";
	//let comments = document.getElementById("comments").value;
	//let filepath = document.getElementById("upload").value;

	let genderElements = document.getElementsByName("gender");

	for (var i = 0; i < genderElements.length; i++) {
		if (genderElements[i].checked) {
			gender = genderElements[i].nextElementSibling.innerText;
		}
	}
	let genderElements1 = document.getElementsByName("gender1");

	for (var i = 0; i < genderElements1.length; i++) {
		if (genderElements1[i].checked) {
			gender1 = genderElements1[i].nextElementSibling.innerText;
		}
	}


	
	var candidateInfo = {
		Id: candidates.length + 1,
		firstName: firstName,
		License:License,
        group:group,
		sessions: sessions,
		experience: experience,
		moment: moment,
		of: of,
		Accountablity: Accountablity,
	    Office: Office,
		gender: gender,
		gender1: gender1,
        objectives:objectives,
        roadmap:roadmap,
        RTT:RTT,
        add:add
        
	};

	return candidateInfo;
}

//Function that manages entry into the Global var
function storeCandidateInfo() {
	candidates.push(readCandidateInfo());
}
function submitForm() {
	
	document.getElementById("formToGrid").style.display = "none";
    document.getElementById("gridToForm").style.display = "block";
	 document.getElementById("submitbtn").style.display = "none";
	 document.getElementById("cancel").style.display = "none";

	if (validateForm()) {
		
		
		if (document.getElementById("submitbtn").innerHTML.toLocaleLowerCase() == "update") {
			
			let candidateinfo = readCandidateInfo();
			
			let candidateindex = candidates.findIndex(
				(candidate) => candidate.Id == candidateId
			);

			candidates[candidateindex].firstName = candidateinfo.firstName;
			candidates[candidateindex].License = candidateinfo.License;
			candidates[candidateindex].group = candidateinfo.group;
			candidates[candidateindex].sessions = candidateinfo.sessions;
			candidates[candidateindex].experience = candidateinfo.experience;
			candidates[candidateindex].moment = candidateinfo.moment;
			candidates[candidateindex].of = candidateinfo.of;
			candidates[candidateindex].Accountablity = candidateinfo.Accountablity;
			candidates[candidateindex].Office = candidateinfo.Office;
			candidates[candidateindex].gender = candidateinfo.gender;
			candidates[candidateindex].gender1 = candidateinfo.gender1;
			candidates[candidateindex].objectives = candidateinfo.objectives;
            candidates[candidateindex].roadmap = candidateinfo.roadmap;
            candidates[candidateindex].RTT = candidateinfo.RTT;
			candidates[candidateindex].add = candidateinfo.add;
		}
		//Save action 
		else {
			storeCandidateInfo();
		}
		generateGrid();
		clearForm();
		showGrid();
	}
}
function generateGrid() {
  //  debugger
	//Clear the table body before forming the table structure

	document.getElementById("tableBody").innerText = "";

	for (var i = 0; i < candidates.length; i++) {
		// Create the dynamic tr,td and append every td in tr and tr in tbody
		let trow = document.createElement("tr");
		trow.className = "color";
		let id = document.createElement("td");
		id.className = "table";
		let firstName = document.createElement("td");
		firstName.className = "table";
        let License = document.createElement("td");
		License.className = "table";
		let group = document.createElement("td");
		group.className = "table";
		let sessions = document.createElement("td");
		sessions.className = "table";
		let experience = document.createElement("td");
		experience.className = "table";
		let moment = document.createElement("td");
		moment.className = "table";
		let of = document.createElement("td");
		of.className = "table";
		let Accountablity = document.createElement("td");
		Accountablity.className = "table";
        let Office = document.createElement("td");
		Office.className = "table";
		let gender = document.createElement("td");
		gender.className = "table";
		let gender1 = document.createElement("td");
		gender1.className = "table";
        let objectives = document.createElement("td");
		objectives.className = "table";
        let roadmap = document.createElement("td");
		roadmap.className = "table";
        let RTT = document.createElement("td");
		RTT.className = "table";
		let add = document.createElement("td");
		add.className = "table";
		let edit = document.createElement("td");
		edit.className = "table";
		let deleteData = document.createElement("td");
		edit.className = "table";

		// append the values in each field resp.
		id.innerHTML = candidates[i].Id;
		firstName.innerHTML = candidates[i].firstName;
        License.innerHTML = candidates[i].License;
		group.innerHTML = candidates[i].group;
		sessions.innerHTML = candidates[i].sessions;
		experience.innerHTML = candidates[i].experience;
		of.innerHTML = candidates[i].of;
		moment.innerHTML = candidates[i].moment;
		Accountablity.innerHTML = candidates[i].Accountablity;
        Office.innerHTML = candidates[i].Office;
        gender.innerHTML = candidates[i].gender;
		gender1.innerHTML = candidates[i].gender1;
        objectives.innerHTML = candidates[i].objectives;
        roadmap.innerHTML = candidates[i].roadmap;
		RTT.innerHTML = candidates[i].RTT;
		add.innerHTML = candidates[i].add;
		edit.innerHTML = "<a onclick='editForm(this)'>Edit</a>";
		deleteData.innerHTML = "<a onclick='deleteCandidate(this)'>Delete</a>";

		trow.appendChild(id);
		trow.appendChild(firstName);
		trow.appendChild(License);
        trow.appendChild(group);
		trow.appendChild(sessions);
		trow.appendChild(experience);
		trow.appendChild(moment);
		trow.appendChild(of);
		trow.appendChild(Accountablity);
		trow.appendChild(Office);
        trow.appendChild(gender);
		trow.appendChild(gender1);
        trow.appendChild(objectives);
        trow.appendChild(roadmap);
        trow.appendChild(RTT);
		trow.appendChild(add);
		trow.appendChild(edit);
		trow.appendChild(deleteData);

		//appending tr in tbody
		document.getElementById("tableBody").appendChild(trow);
	}
}
function showForm() {
    document.getElementById("formToGrid").style.display = "block";
    document.getElementById("gridToForm").style.display = "none";
}
function showGrid() {
    document.getElementById("formToGrid").style.display = "none";
    document.getElementById("gridToForm").style.display = "block";
}
//Prepare the form for adding a new customer
function addCandidate() {
	clearForm(); // to clear the form
	document.getElementById("submitbtn").innerHTML = "Submit";
	document.getElementById("submitbtn").style.display = "block";
	showForm(); // to show the form to user

}

//clearing all fields
function clearForm() {

	document.getElementById("firstName").value="";
	//document.getElementById("crew").value="";
	document.getElementById("License").value;
document.getElementById("group").value="";
document.getElementById("sessions").value="";
document.getElementById("experience").value="";
document.getElementById("moment").value="";
document.getElementById("of").value="";
 document.getElementById("Accountablity").value="";
	document.getElementById("Office").value= "";
 
 // document.getElementById("gender").value="";
  //document.getElementById("gender1").value="";
 document.getElementById("objectives").value ="";
 document.getElementById("roadmap").value="";
 document.getElementById("RTT").value ="";
 document.getElementById("add").value="";
	
	
	document.getElementById("firstNameError").innerHTML="";
	 document.getElementById("LicenseError").innerHTML=" ";
	// document.getElementById("lastNameError").innerHTML="";

 document.getElementById("groupError").innerHTML="";
 document.getElementById("sessionsError").innerHTML="";
// document.getElementById("roleError").innerHTML="";
 document.getElementById("experienceError").innerHTML="";
 document.getElementById("momentError").innerHTML="";
  document.getElementById("ofError").innerHTML="";
     document.getElementById("AccountablityError").innerHTML= "";
   document.getElementById("OfficeError").innerHTML="";
  document.getElementById("gender1Error").innerHTML ="";
  document.getElementById("genderError").innerHTML ="";
  document.getElementById("objectivesError").innerHTML="";
  document.getElementById("roadmapError").innerHTML ="";
  document.getElementById("RTTError").innerHTML="";
  document.getElementById("addError").innerHTML="";
}



function editForm(obj) {
//	showForm();

	document.getElementById("submitbtn").innerHTML= "update";
	document.getElementById("submitbtn").style.display = "block";
	

	var edit = obj.closest("tr");
	candidateId = parseInt(edit.cells[0].innerText);
	let candidate = findCandidate(candidateId);
	prefillForm(candidate);
	document.getElementById("submitbtn").innerHTML = "Update";
	showForm(); //form is displayed
}
//Find candidate based on the id
function findCandidate(candidateId) {
	return candidates.find((candidate) => candidate.Id == candidateId);
}

function prefillForm(candidateInfo) {
	
	document.getElementById("firstName").value = candidateInfo.firstName;
	//document.getElementById("middleName").value = candidateInfo.middleName;
	document.getElementById("License").value = candidateInfo.License;

	switch (candidateInfo.gender.toLowerCase()) {
		case "male":
			document.getElementById("male").checked = true;
			break;
		case "female":
			document.getElementById("female").checked = true;
			break;
		case "other":
			document.getElementById("other").checked = true;
			break;
	}
	
	switch (candidateInfo.gender1.toLowerCase()) {
		case "1":
			document.getElementById("1").checked = true;
			break;
		case "2":
			document.getElementById("2").checked = true;
			break;
		case "3":
			document.getElementById("3").checked = true;
			break;
			case "4":
				document.getElementById("4").checked = true;
				break;
				case "5":
					document.getElementById("5").checked = true;
					break;
					case "6":
						document.getElementById("6").checked = true;
						break;
						case "6":
							document.getElementById("6").checked = true;
							break;
							case "7":
								document.getElementById("7").checked = true;
								break;
								case "8":
									document.getElementById("8").checked = true;
									break;
									case "9":
										document.getElementById("9").checked = true;
										break;
										case "10":
											document.getElementById("10").checked = true;
											break;
	}


	
	///////////////////
	document.getElementById("sessions").value =candidateInfo.sessions;
    document.getElementById("experience").value=candidateInfo.experience;
    document.getElementById("moment").value=candidateInfo.moment;
    document.getElementById("of").value=candidateInfo.of;
    document.getElementById("Accountablity").value=candidateInfo.Accountablity;
    document.getElementById("Office").value=candidateInfo.Office;
    // document.getElementById("gender1").innerHTML=candidateInfo.gender1;
	// document.getElementById("gender").innerHTML=candidateInfo.gender;
	document.getElementById("objectives").value= candidateInfo.objectives;
    document.getElementById("roadmap").value=candidateInfo.roadmap;
    document.getElementById("RTT").value =candidateInfo.RTT;
    document.getElementById("add").value=candidateInfo.add;

}
function deleteCandidate(candidateobj) {
    var deleterow = candidateobj.closest("tr");
    let delcandidateId = parseInt(deleterow.cells[0].innerText);
    if (confirm("Are you sure you want to delete this Candidate?")) {
         let candidateindex = candidates.findIndex(candidate => candidate.Id == delcandidateId);
		//let candidateindex = delcandidateId-1;

        candidates.splice(candidateindex, 1);
        candidates.forEach((candidate, index) => {
            candidate.Id = index + 1;
        });
    }
    generateGrid();//Forming the Grid
}
