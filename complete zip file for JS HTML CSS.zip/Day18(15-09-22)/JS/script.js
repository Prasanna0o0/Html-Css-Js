
var candidates = [];

var candidateId="";
document.getElementById("gridToForm").style.display = "none";
//first name validation
function validateFirstName() {
	
	let message = document.getElementById("firstName");
	let error = document.getElementById("firstNameError");
	if (message.value == "") {
		error.innerHTML = "First name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//lastname validation
function validateLastName() {
	let message = document.getElementById("lastName");
	let error = document.getElementById("lastNameError");
	if (message.value == "") {
		error.innerHTML = "Last Name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}


//validating gender
// function validateGender() {
// 	if (
// 		document.getElementById("male").checked == true ||
// 		document.getElementById("female").checked == true ||
// 		document.getElementById("other").checked == true
// 	) {
// 		document.getElementById("genderError").innerHTML = "";
// 		return true;
// 	} else {
// 		document.getElementById("genderError").innerHTML =
// 			"Please select any one option";
// 		return false;
// 	}
// }
//email validation
// function validateEmail() {
// 	let message = document.getElementById("e-mail");
// 	let emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
// 	if (message.value != "") {     // Required Field Validation
// 		if (message.value.match(emailFormat)) {  // RegEx Validation
// 			document.getElementById("e-mailError").innerHTML = "";
// 			return true;
// 		} else {
// 			document.getElementById("e-mailError").innerHTML =
// 				"Enter in correct format";
// 			return false;
// 		}
// 	} else {
// 		document.getElementById("e-mailError").innerHTML = "Email ID is required";
// 		return false;
// 	}
// }

function validateNumber() {
	let message = document.getElementById("mobileNumber");
	var regex = "/^[0-9]{10}$/";
    if (message.value != "") {// Required Field Validation
	if (message.value.length == 10 && message.value != regex) { 
		document.getElementById("mobileNumberError").innerHTML = "";
		return true;
	} else {
		document.getElementById("mobileNumberError").innerHTML =
			"Enter valid input";
		return false;
	}
}
else{
    document.getElementById("mobileNumberError").innerHTML = "Mobile Number  is required";
		return false;
}
}

//validating file
// function validateFile() {
// 	let error = document.getElementById("fileError");

	
// 	if (document.getElementById("upload").value == "") {
// 		error.innerHTML = "Please select any file";
// 		return false;
// 	} else {
		

// 		let extn = document.getElementById("upload").value.split(".").pop();
// 		if (
// 			extn.toLowerCase() == "jpg" ||
// 			extn.toLowerCase() == "jpeg" ||
// 			extn.toLowerCase() == "png" ||
// 			extn.toLowerCase() == "pdf" ||
// 			extn.toLowerCase() == "doc" ||
// 			extn.toLowerCase() == "docx"
// 		) {
// 			error.innerHTML = "";
// 			return true;
// 		} else {
// 			error.innerHTML = "Upload a file with Valid format";
// 			return false;
// 		}
// 	}
// }


function strToDate(datestr) {
	let dateArray = datestr.split("-");
	return new Date(dateArray[0], dateArray[1], dateArray[2]);
}

//joined date validation
function validateJoinedDate() {

	if (document.getElementById("joinedDate").value == "") {
		document.getElementById("joinedDateError").innerHTML =
			"*Birthday date is required";
		return false;
	}
	
	else if (document.getElementById("endDate").value != "") {
		let joinedDate = strToDate(document.getElementById("joinedDate").value);
		let endDate = strToDate(document.getElementById("endDate").value);

		
		if (endDate < joinedDate) {
			document.getElementById("joinedDateError").innerHTML =
				"*birthday date must be less than the End date";
		} else {
			document.getElementById("joinedDateError").innerHTML = "";
			return true;
		}
	}
	
	else {
		document.getElementById("joinedDateError").innerHTML = "";
		return true;
	}
}

//to date validation End date 
function validateEndDate() {
	
	if (document.getElementById("endDate").value == "") {
		document.getElementById("endDateError").innerHTML = "*End date is required";
		return false;
	}
	
	else if (document.getElementById("joinedDate").value != "pas----------") {
		let joinedDate = strToDate(document.getElementById("joinedDate").value);
		let endDate = strToDate(document.getElementById("endDate").value);

		
		if (endDate < joinedDate) {
			document.getElementById("endDateError").innerHTML =
				"*End date must be greater than the Joined date";
		} else {
			document.getElementById("endDateError").innerHTML = "";
			return true;
		}
	}
	
	else {
		document.getElementById("endDateError").innerHTML = "";
		return true;
	}
}

//validating verification Checkbox
function verification() {
	let error = document.getElementById("verificationError");
	if (document.getElementById("verification").checked) { //Required Validation
		error.innerHTML = "";
		return true;
	} else {
		error.innerHTML = "Please select ";
		return false;
	}
}
//crew validation
function crew() {
	let error = document.getElementById("crewError");
	if (document.getElementById("crew").value == "select") {
		error.innerHTML = "Please select any option";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}

//Role validation
function Role() {
	let error = document.getElementById("roleError");
	if (document.getElementById("role").value == "select") {
		error.innerHTML = "Please select any option";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// Cell phone number
function cellPhoneNumber() {
	let message = document.getElementById("cell");
	var regex = "/^[0-9]{10}$/";
    if (message.value != "") {// Required Field Validation
	if (message.value.length == 10 && message.value != regex) { 
		document.getElementById("cellError").innerHTML = "";
		return true;
	} else {
		document.getElementById("cellError").innerHTML =
			"Enter valid input";
		return false;
	}
}
else{
    document.getElementById("cellError").innerHTML = "Cell Phone Number  is required !";
		return false;
}
}
// city validation 
function city() {
	
	let message = document.getElementById("city");
	let error = document.getElementById("cityError");
	if (message.value == "") {
		error.innerHTML = "city name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// emergrncy contact number 
function contactNumber() {
	let message = document.getElementById("contactNumber1");
	var regex = "/^[0-9]{10}$/";
    if (message.value != "") {// Required Field Validation
	if (message.value.length == 10 && message.value != regex) { 
		document.getElementById("contactNumberError").innerHTML = "";
		return true;
	} else {
		document.getElementById("contactNumberError").innerHTML =
			"Enter valid input";
		return false;
	}
}
}
// Preferred validation
function Preferred() {
	
	let message = document.getElementById("Preferred");
	let error = document.getElementById("PreferredError");
	if (message.value == "") {
		error.innerHTML = "Preferred name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}

// Experience validation
function Experience() {
	
	let message = document.getElementById("Experience");
	let error = document.getElementById("ExperienceError");
	if (message.value == "") {
		error.innerHTML = "Experience is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//Home validation
function Home() {
	
	let message = document.getElementById("Home");
	let error = document.getElementById("HomeError");
	if (message.value == "") {
		error.innerHTML = "Experience is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// emergency contact name
function contactName() {
	
	let message = document.getElementById("EmergencycontactName");
	let error = document.getElementById("EmergencycontactNameError");
	if (message.value == "") {
		error.innerHTML = "Contact name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//validating all fields to show error messages during submit
function validateForm() {
	var errorCount = 0;
	if (!validateFirstName()) {
		errorCount++;
	}

	if (!validateLastName()) {
		errorCount++;
	}
	if (!crew()) {
		errorCount++;
	}
	if (!Role()) {
		errorCount++;
	}
	if (!cellPhoneNumber()) {
		errorCount++;
	}
	if (!city()) {
		errorCount++;
	}

	// if (!validateJob()) {
		// errorCount++;
	// }
	if (!contactNumber()) {
		errorCount++;
	}
	if (!Preferred()) {
		errorCount++;
	}
	if (!Experience()) {
		errorCount++;
	}
    if (!Home()) {
		errorCount++;
	}
    if (!contactName()) {
		errorCount++;
	}
	if (errorCount > 0) { 
		return false;
	}
	return true;
}
//Submit action for Update and Save operation
//Function to read the candidate information from the form and return the candidate as Json object
function readCandidateInfo() {
	debugger
	let firstName = document.getElementById("firstName").value;
	let crew = document.getElementById("crew").value;
	let lastName = document.getElementById("lastName").value;

	let cell = document.getElementById("cell").value;
	let city = document.getElementById("city").value;
	let role = document.getElementById("role").value;
	let joinedDate = document.getElementById("joinedDate").value;
	let endDate = document.getElementById("endDate").value;
    let contactNumber1 = document.getElementById("contactNumber1").value;
    let Preferred = document.getElementById("Preferred").value;
    let Experience = document.getElementById("Experience").value;
    let Home = document.getElementById("Home").value;
    let EmergencycontactName = document.getElementById("EmergencycontactName").value;
   // let Experience = document.getElementById("Experience").value;
    
//	let gender = "";
	//let comments = document.getElementById("comments").value;
	//let filepath = document.getElementById("upload").value;

	//let genderElements = document.getElementsByName("gender");

	// for (var i = 0; i < genderElements.length; i++) {
	// 	if (genderElements[i].checked) {
	// 		gender = genderElements[i].nextElementSibling.innerText;
	// 	}
	// }

	
	var candidateInfo = {
		Id: candidates.length + 1,
		firstName: firstName,
        lastName:lastName,
		crew: crew,
		lastName: lastName,
		cell: cell,
		city: city,
		role: role,
	//	jobPosition: jobPosition,
		joinedDate: joinedDate,
		endDate: endDate,
        contactNumber1:contactNumber1,
        Preferred:Preferred,
        Experience:Experience,
        Home:Home,
        EmergencycontactName:EmergencycontactName
	};

	return candidateInfo;
}

//Function that manages entry into the Global var
function storeCandidateInfo() {
	candidates.push(readCandidateInfo());
}
function submitForm() {
	debugger
	document.getElementById("submitbtn").style.display = "none";
	document.getElementById("cancel").style.display = "none";

	if (validateForm()) {
		
		if (document.getElementById("submitbtn").innerHTML.toLocaleLowerCase() == "update") {
			let candidateinfo = readCandidateInfo();
			let candidateindex = candidates.findIndex(
				(candidate) => candidate.Id == candidateId
			);

			candidates[candidateindex].firstName = candidateinfo.firstName;
			candidates[candidateindex].crew = candidateinfo.crew;
			candidates[candidateindex].lastName = candidateinfo.lastName;
			candidates[candidateindex].cell = candidateinfo.cell;
			candidates[candidateindex].city = candidateinfo.city;
			candidates[candidateindex].role = candidateinfo.role;
			candidates[candidateindex].contactNumber1 = candidateinfo.contactNumber1;
			candidates[candidateindex].joinedDate = candidateinfo.joinedDate;
			candidates[candidateindex].endDate = candidateinfo.endDate;
			candidates[candidateindex].Preferred = candidateinfo.Preferred;
			candidates[candidateindex].Experience = candidateinfo.Experience;
            candidates[candidateindex].Home = candidateinfo.Home;
            candidates[candidateindex].EmergencycontactName = candidateinfo.EmergencycontactName;
		}
		//Save action 
		else {
			storeCandidateInfo();
		}
		generateGrid();
		clearForm();
		showGrid();
	}
}
function generateGrid() {
    debugger
	//Clear the table body before forming the table structure

	document.getElementById("tableBody").innerText = "";

	for (var i = 0; i < candidates.length; i++) {
		// Create the dynamic tr,td and append every td in tr and tr in tbody
		let trow = document.createElement("tr");
		trow.className = "color";
		let id = document.createElement("td");
		id.className = "table";
		let firstName = document.createElement("td");
		firstName.className = "table";
        let lastName = document.createElement("td");
		lastName.className = "table";
		let crew = document.createElement("td");
		crew.className = "table";
		let cell = document.createElement("td");
		cell.className = "table";
		let city = document.createElement("td");
		city.className = "table";
		let contactNumber1 = document.createElement("td");
		contactNumber1.className = "table";
		let joinedDate = document.createElement("td");
		joinedDate.className = "table";
		let endDate = document.createElement("td");
		endDate.className = "table";
        let EmergencycontactName = document.createElement("td");
		EmergencycontactName.className = "table";
        let Preferred = document.createElement("td");
		Preferred.className = "table";
        let Home = document.createElement("td");
		Home.className = "table";
        let Experience = document.createElement("td");
		Experience.className = "table";
        let role = document.createElement("td");
		role.className = "table";
		let edit = document.createElement("td");
		edit.className = "table";
		let deleteData = document.createElement("td");
		edit.className = "table";

		// append the values in each field resp.
		id.innerHTML = candidates[i].Id;
		firstName.innerHTML = candidates[i].firstName;
        lastName.innerHTML = candidates[i].lastName;
		crew.innerHTML = candidates[i].crew;
		cell.innerHTML = candidates[i].cell;
		city.innerHTML = candidates[i].city;
		contactNumber1.innerHTML = candidates[i].contactNumber1;
		joinedDate.innerHTML = candidates[i].joinedDate;
		endDate.innerHTML = candidates[i].endDate;
        EmergencycontactName.innerHTML = candidates[i].EmergencycontactName;
        Home.innerHTML = candidates[i].Home;
        Experience.innerHTML = candidates[i].Experience;
        role.innerHTML = candidates[i].role;
		edit.innerHTML = "<a onclick='editForm(this)'>Edit</a>";
		deleteData.innerHTML = "<a onclick='deleteCandidate(this)'>Delete</a>";

		trow.appendChild(id);
		trow.appendChild(firstName);
        trow.appendChild(lastName);
		trow.appendChild(crew);
		trow.appendChild(cell);
		trow.appendChild(city);
		trow.appendChild(contactNumber1);
		trow.appendChild(joinedDate);
		trow.appendChild(endDate);
        trow.appendChild(EmergencycontactName);
        trow.appendChild(Home);
        trow.appendChild(Experience);
        trow.appendChild(role);
		trow.appendChild(edit);
		trow.appendChild(deleteData);

		//appending tr in tbody
		document.getElementById("tableBody").appendChild(trow);
	}
}
function showForm() {
    document.getElementById("formToGrid").style.display = "block";
    document.getElementById("gridToForm").style.display = "none";
}
function showGrid() {
    document.getElementById("formToGrid").style.display = "none";
    document.getElementById("gridToForm").style.display = "block";
}
//Prepare the form for adding a new customer
function addCandidate() {
	clearForm(); // to clear the form
	document.getElementById("submitbtn").innerHTML = "Submit";
	document.getElementById("submitbtn").style.display = "block";
	showForm(); // to show the form to user

}

//clearing all fields
function clearForm() {

	document.getElementById("firstName").value="";
	document.getElementById("crew").value ="";
	document.getElementById("lastName").value;
document.getElementById("cell").value="";
document.getElementById("city").value="";
document.getElementById("role").value="";
document.getElementById("joinedDate").value="";
document.getElementById("endDate").value="";
 document.getElementById("contactNumber1").value="";
	document.getElementById("Preferred").value= "";
  document.getElementById("Experience").value="";
 document.getElementById("Home").value ="";
 document.getElementById("EmergencycontactName").value="";

	
	
	document.getElementById("firstNameError").innerHTML="";
	 document.getElementById("crewError").innerHTML=" ";
	 document.getElementById("lastNameError").innerHTML="";

 document.getElementById("cellError").innerHTML="";
 document.getElementById("cityError").innerHTML="";
 document.getElementById("roleError").innerHTML="";
 document.getElementById("joinedDateError").innerHTML="";
 document.getElementById("endDateError").innerHTML="";
  document.getElementById("contactNumberError").innerHTML="";
     document.getElementById("PreferredError").innerHTML= "";
   document.getElementById("ExperienceError").innerHTML="";
  document.getElementById("HomeError").innerHTML ="";
  document.getElementById("EmergencycontactNameError").innerHTML="";
}



function editForm(obj) {
	debugger
	document.getElementById("submitbtn").style.display = "block";
	

	var edit = obj.closest("tr");
	candidateId = parseInt(edit.cells[0].innerText);
	let candidate = findCandidate(candidateId);
	prefillForm(candidate);
	document.getElementById("submitbtn").innerHTML = "Update";
	showForm(); //form is displayed
}
//Find candidate based on the id
function findCandidate(candidateId) {
	return candidates.find((candidate) => candidate.Id == candidateId);
}

function prefillForm(candidateInfo) {
	debugger
	document.getElementById("firstName").value = candidateInfo.firstName;
	//document.getElementById("middleName").value = candidateInfo.middleName;
	document.getElementById("lastName").value = candidateInfo.lastName;

	// switch (candidateInfo.gender.toLowerCase()) {
	// 	case "male":
	// 		document.getElementById("male").checked = true;
	// 		break;
	// 	case "female":
	// 		document.getElementById("female").checked = true;
	// 		break;
	// 	case "other":
	// 		document.getElementById("other").checked = true;
	// 		break;
	// }

	
	///////////////////
	document.getElementById("crew").value =candidateInfo.crew;
    document.getElementById("cell").value=candidateInfo.cell;
    document.getElementById("city").value=candidateInfo.city;
    document.getElementById("role").value=candidateInfo.role;
    document.getElementById("joinedDate").value=candidateInfo.joinedDate;
    document.getElementById("endDate").value=candidateInfo.endDate;
    document.getElementById("contactNumber1").value=candidateInfo.contactNumber1;
	document.getElementById("Preferred").value= candidateInfo.Preferred;
    document.getElementById("Experience").value=candidateInfo.Experience;
    document.getElementById("Home").value =candidateInfo.Home;
    document.getElementById("EmergencycontactName").value=candidateInfo.EmergencycontactName;

}
function deleteCandidate(candidateobj) {
    var deleterow = candidateobj.closest("tr");
    let delcandidateId = parseInt(deleterow.cells[0].innerText);
    if (confirm("Are you sure you want to delete this Candidate?")) {
         let candidateindex = candidates.findIndex(candidate => candidate.Id == delcandidateId);
		//let candidateindex = delcandidateId-1;

        candidates.splice(candidateindex, 1);
        candidates.forEach((candidate, index) => {
            candidate.Id = index + 1;
        });
    }
    generateGrid();//Forming the Grid
}
