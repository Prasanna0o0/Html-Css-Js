var objindex = 0; 
var editRowId = ""; // gol variable
console.log("scripts.....");
function Submit() {

console.log("function works........");
    var objTr =document.createElement("tr");
// console.log("objTr");
    objTr.id = "tr" +objindex;
   
    objTr.appendChild(bindfunction("fn" +objindex,"first"));
   objTr.appendChild(bindfunction("mn" +objindex,"middle"));
    objTr.appendChild(bindfunction("ln" +objindex,"last"));
// create an table data tag for edit & del btn 
    
   var objTd =document.createElement("td");
    objTd.id ="action" + objindex;
    // btn edit
    var Tdimg =document.createElement("img"); //create an img tag using createElement 
    console.log(Tdimg);
    Tdimg.src="image/edit.png";
    Tdimg.id="imgedit" + objindex;
    Tdimg.height="25";
    Tdimg.width="25";
    Tdimg.setAttribute("onclick","editrow(this)");
    objTd.appendChild(Tdimg)
    objTr.appendChild(objTd)


    // btn del
    var Tdimg =document.createElement("img"); //create an img tag using createElement 
    console.log(Tdimg);
    Tdimg.src="image/delete.png";
    Tdimg.id="imgdelete" + objindex;
    Tdimg.height="25";
    Tdimg.width="25";
    Tdimg.setAttribute("onclick","delrow(this)");
    objTd.appendChild(Tdimg)
    objTr.appendChild(objTd)
    
     // append the td tag into tr tag 
    
   

    document.getElementById("tablebody").appendChild(objTr); // append the tr tag into table body

    objindex =objindex + 1; // to increase an index of an input value 
    // this used to each user input value has an unique id as index for identify the input value ......

    // hide form and show table
    document.getElementById("table").style.display= "block";
    document.getElementById("form").style.display= "none";


    clear();
    newregbtn();
    
}


                   // fn0 ,firstname
function bindfunction(id,inputtagid) { 
    // create an td tag for first,middle,last name 
    var objTd=document.createElement("td");
    objTd.id=id;
    objTd.innerText=document.getElementById(inputtagid).value;
    return objTd;

}
function clear() {

    document.getElementById("first").value="";
    document.getElementById("middle").value="";
    document.getElementById("last").value="";
    editRowId = ""
}

// delete function for delete the element input in table
function deleterow(){
    var ctrlid =ctrl.id;
    var rowid = ctrlid.replace("imgdelete","tr");
    document.getElementById(rowid).remove();
    document.getElementById("newreg").style.display="block";
}
// edit function for  update element  input in table.............
function editrow(ctrl){
    console.log("edit............"+ctrl);
    var ctrlid= ctrl.id;
    var fnid = ctrlid.replace("imgedit","fn");
    var mnid =ctrlid.replace("imgedit","mn");
    var lnid =ctrlid.replace("imgedit","ln");

    document.getElementById("first").value=document.getElementById(fnid).innerHTML;
    document.getElementById("middle").value=document.getElementById(mnid).innerHTML;
    document.getElementById("last").value=document.getElementById(lnid).innerHTML;

    editRowId = ctrlid.replace("imgedit", "");
    document.getElementById("table").style.display = "none";
    document.getElementById("form").style.display = "block";
    document.getElementById("newreg").style.display="none";
    update_btn();
   
}
function update_btn() {
    document.getElementById("submit").style.display = "none";
    document.getElementById("update").style.display = "block";
}
function updatetotable(){
    
    console.log("hello............");
    // form ----> table/grid
var editRowid_dup = editRowId; 
var fnid="fn"+editRowId;
var mnid="mn"+editRowId;
var lnid="ln"+editRowId;
    document.getElementById(fnid).innerText=document.getElementById("first").value;
    document.getElementById(mnid).innerText=document.getElementById("middle").value;
    document.getElementById(lnid).innerText=document.getElementById("last").value;

    document.getElementById("form").style.display = "none";
    document.getElementById("newreg").style.display = "block";
    document.getElementById("table").style.display = "block";
    
    
   
}
///////////////////////////////
function newregbtn(){
    document.getElementById("newreg").style.display="block";
}

function show(){
    document.getElementById("table").style.display= "none";
    document.getElementById("form").style.display= "block";
    document.getElementById("newreg").style.display="none";
   document.getElementById("submit").style.display="block";
    document.getElementById("update").style.display="none";
    clear();

}

function delrow(ctrl){
    console.log("image id  :"+ctrl.id);
    var ctrlid = ctrl.id;
    var rowid =ctrlid.replace("imgdelete","tr");
    console.log(rowid);
    document.getElementById(rowid).remove();
}

// validation --------------------------------------------------------------------------

function firstName() {
    if (document.getElementById("first").value.trim() == "") {
       document.getElementById('firstError').innerHTML="First Name is Required !"

       return false;
    }
    else{
        document.getElementById('firstError').innerHTML="Pass....."
    }
};
function middleName() {
    if (document.getElementById("middle").value.trim() == "") {
       document.getElementById('middleError').innerHTML="Middle Name is Required !"
       return false;
    }
    else{
        document.getElementById('middleError').innerHTML="Pass....."
    }
};
function lastName() {
    if (document.getElementById("last").value.trim() == "") {
       document.getElementById('lastError').innerHTML="Last Name is Required !"
       return false;
    }
    else{
        document.getElementById('lastError').innerHTML="Pass....."
    }
};