try {
    function name(params) {
        // condition....
    }
} catch (error) {
    console.log(error.message);
}