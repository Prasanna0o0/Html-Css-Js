
//task-2 usecase--3
// creating a json---------------------------------------------------------------------------------
const data={
    "name":"jhone",
    "age" :22,
    "hobby" : {
        "reading" :true,
        "gaming" :true,
        "sports" :"football"
    },
    "class" :["javascript","html","css"] 
} 
console.log(" name : "+data.name+" ,age : "+data.age+" ,hobby  : "+data.hobby.reading+" , "+data.hobby.gaming+" , "+data.hobby.sports+" ,class :["+data.class[0]+","+data.class[1]+","+data.class[2]+"]");

//creating an obj
// (00)
const todos=[
 {
    id   :1211,
    title:"Person1",
    description :"A person's appearance can be described in many ways. It is possible to tell about the person's style of clothing, manner of walking, colour and style of hair, facial appearance, body shape, and expression or even the person's way of talking.",
    completed : "Yes"
},
 {
    id :1212,
    title:"Person2",
    description :"A person's appearance can be described in many ways. It is possible to tell about the person's style of clothing, manner of walking, colour and style of hair, facial appearance, body shape, and expression or even the person's way of talking.",
    completed : "No"
}]

console.log("  "+"id :"+todos[0].id+" title :"+todos[0].title+" description :"+todos[0].description+" completed :"+todos[0].completed);

console.log("  " +"id :"+todos[1].id+" title :"+todos[1].title+" description :"+todos[1].description+" completed :"+todos[1].completed);
