//const domain = ["DataScience", "Dev", "SalesForce", "DevOps"];
// let result = domain.join(' and ');

// console.log(result)\
//debugger

const domain1= ["DataScience12", "Dev12", "SalesForce12", "DevOps12"];


const domain = ["DataScience", "Dev", "SalesForce", "DevOps"];
const age=[12,18,20,22,17];
const result = domain1.includes("Dev12", 2);
const oriage=age.filter(agefun);  
const oriag=age.find(agefun); 
const oriage1=age.findIndex(agefun); 
const oriage12=age.forEach(agefun1);
const indexof=age.indexOf(20); 
const join=age.join(" "); /// convert into string
const map1=domain.map(agefun12); //copy the array save into another variable.
const map11=age.map(agefun12);
const push=age.push(12121);
function agefun(age){
 return age >=18;
}
function agefun1(item,index){
console.log("foreach :"+item,index);
}
function agefun12(item ,index){
    
    return index,item;
    }
console.log("map11 : "+map11);
console.log("include---domain1 :"+result) ;
console.log("fliter---age :"+oriage);
console.log("find---age :"+oriag);// shows the element of the first finded array 
console.log("findindex---age :"+oriage1);// shows index of the first finded array
console.log("indexof ---age :"+indexof);
console.log("join ---age :"+join);
console.log("isArrays --age :"+Array.isArray(age));
console.log("push ---age : length-"+push+" "+age);



