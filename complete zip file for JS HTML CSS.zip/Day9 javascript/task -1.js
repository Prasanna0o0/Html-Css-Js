let number1=10;
let number2=20;

let simple_calculator =(num1,num2,operation)  =>{

    if(operation=="addtion"){
        console.log(num1+num2); 
    }
    else if(operation=="subtraction"){
        console.log(num1-num2);
    }
    else if(operation== "multiplication"){
        console.log(num1*num2);
    }
}

simple_calculator(2,4,"multiplication");