let arr=["one","two","three","four","five"];
let arr1=["six","seven","eight","nine","ten"];
let arr2=arr.concat(arr1);

console.log("concat :" +arr.concat(arr1));
console.log("lengthh of an Arrays :"+arr2.length);
console.log("slice func :"+arr.slice(0,3));
console.log("splice :" +arr2.splice(0,3,1,2,3));
console.log(arr2.toString());
console.log("reverse :"+arr2.reverse());
