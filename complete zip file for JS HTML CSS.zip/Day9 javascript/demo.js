// let IntegerArray=[0,1,2,3,4,5]
// let iterator=0;
// while (iterator==IntegerArray[iterator])//checks whether the iterator is equal to the IntegerArray Elements
// {
    
//     console.log(`${iterator} exists in array "IntegerArray" `);
//     iterator=iterator+1;
// }

// let fruit =["121","243","2343"];

// console.log(fruit instanceof Array );
// console.log(fruit instanceof Object );

let pa="lp";
 pa="1";
 
console.log(pa);

