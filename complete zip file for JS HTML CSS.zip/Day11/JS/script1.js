function universal(){
    // emailValid();
    // passwordValid();
    let op= document.getElementById("email1").value.trim();
    console.log(op);
    emailValid(op);
    if (document.getElementById("first").value.trim() == "") {
        document.getElementById('firstError').innerHTML="First Name is Required !"
     }
     //middle name
     if (document.getElementById("middle").value.trim() == "") {
        document.getElementById('middleError').innerHTML="Middle Name is Required !"
       
     }
     // last name
     if (document.getElementById("last").value.trim() == "") {
        document.getElementById('lastError').innerHTML="Last Name is Required !"
        
     }
     //dropdown 
     if(document.getElementById("dropdown").value.trim()==""){
        document.getElementById('dropError').innerHTML=" Error Selected any country....!"
    }
    // radius box
    var isCheckBoxChecked1 = false;
    document.getElementsByName("gender").forEach(function(ctrl, index){
        if(ctrl.checked){
            isCheckBoxChecked1 = true;
        }
   });
  if(!isCheckBoxChecked1){
         document.getElementById('radiusError').innerHTML = "Error Skill Sets must be checked.......!"
   
   }
    // check box 
    var isCheckBoxChecked = false;
    document.getElementsByName("checkBox").forEach(function(ctrl, index){
        if(ctrl.checked){
            isCheckBoxChecked = true;
        }
   });
  if(!isCheckBoxChecked){
         document.getElementById('checkError').innerHTML = "Error Skill Sets must be checked....!"
     return false;
   }
   

    else{
        document.getElementById('firstError').innerHTML="Pass.....";
        document.getElementById('middleError').innerHTML="Pass.....";
        document.getElementById('lastError').innerHTML="Pass.....";
        document.getElementById('dropError').innerHTML="Pass......";
        document.getElementById('checkError').innerHTML = "Pass.....!";
        document.getElementById('radiusError').innerHTML = "Pass.....!";
        document.getElementById('checkError').innerHTML = "Pass.....!";
       
    }
    


};


// function firstName() {
//     if (document.getElementById("first").value.trim() == "") {
//        document.getElementById('firstError').innerHTML="First Name is Required !"

//        return false;
//     }
//     else{
//         document.getElementById('firstError').innerHTML="Pass....."
//     }
// };
// function middleName() {
//     if (document.getElementById("middle").value.trim() == "") {
//        document.getElementById('middleError').innerHTML="Middle Name is Required !"
//        return false;
//     }
//     else{
//         document.getElementById('middleError').innerHTML="Pass....."
//     }
// };
// function lastName() {
//     if (document.getElementById("last").value.trim() == "") {
//        document.getElementById('lastError').innerHTML="Last Name is Required !"
//        return false;
//     }
//     else{
//         document.getElementById('lastError').innerHTML="Pass....."
//     }
// };

// function dropDown(){
//     if(document.getElementById("dropdown").value.trim()==""){
//         document.getElementById('dropError').innerHTML="Selected any country....!"
//     }
//     else{
//         document.getElementById('dropError').innerHTML="Pass......"
//     }
// };
// function checkBox(){
   
//     var isCheckBoxChecked = false;
//     document.getElementsByName("checkBox").forEach(function(ctrl, index){
//         if(ctrl.checked){
//             isCheckBoxChecked = true;
//         }
//    });
//   if(!isCheckBoxChecked){
//          document.getElementById('checkError').innerHTML = "Skill Sets must be checked!"
//      return false;
//    }
//    else{
//     document.getElementById('checkError').innerHTML = "Pass.....!"
//    }
// };

// function radiusBox(){
   
//     var isCheckBoxChecked1 = false;
//     document.getElementsByName("gender").forEach(function(ctrl, index){
//         if(ctrl.checked){
//             isCheckBoxChecked1 = true;
//         }
//    });
//   if(!isCheckBoxChecked1){
//          document.getElementById('radiusError').innerHTML = "Skill Sets must be checked!"
//      return false;
//    }
//    var isCheckBoxChecked = false;
//    document.getElementsByName("checkBox").forEach(function(ctrl, index){
//        if(ctrl.checked){
//            isCheckBoxChecked = true;
//        }
//   });
//  if(!isCheckBoxChecked){
//         document.getElementById('checkError').innerHTML = "Skill Sets must be checked!"
//     return false;
//   }
//    else{
//     document.getElementById('radiusError').innerHTML = "Pass.....!"
//     document.getElementById('checkError').innerHTML = "Pass.....!"
//    }
   
// };
function emailValid(inputText) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!inputText.value.match(mailformat)) {
          document.getElementById('emailError').innerHTML="Email is not in the correct format!"
        inputText.focus();
        return false;
    }
    else{
        document.getElementById('emailError').innerHTML="pass.....!"
    }
};
function passwordValid(inputText) {
 
    var mobileformat = new RegExp(/(?=.*[0-9])(?=.{10,})/);
    if (!inputText.value.match(mobileformat)) {
          document.getElementById('mobileError').innerHTML="mobile number is not in the correct format !"
        inputText.focus();
        return false;
    }
    else{
        document.getElementById('mobileError').innerHTML="pass.....!"
    }
};

// function universal(){
//     firstName();
//     middleName();
//     lastName();
//     dropDown();
//     radiusBox();
// };