debugger
function name(par,par1) {
   
    console.log(par,par1);
}

name(12,13)
