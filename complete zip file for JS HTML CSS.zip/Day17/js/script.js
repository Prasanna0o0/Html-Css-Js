var candidates = [];

var candidateId="";

//first name validation
function validateFirstName() {
	
	let message = document.getElementById("firstName");
	let error = document.getElementById("firstNameError");
	if (message.value == "") {
		error.innerHTML = "First name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// work days
function workdays() {
	
	let message = document.getElementById("work");
	let error = document.getElementById("workError");
	if (message.value == "") {
		error.innerHTML = "Input is required !";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
function lead() {
	
	let message = document.getElementById("lead");
	let error = document.getElementById("leadError");
	if (message.value == "") {
		error.innerHTML = "Input is required !";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// leave type
function leave() {
	
	let error = document.getElementById("leaveError");
	if (document.getElementById("leave").value == "select") {
		error.innerHTML = "Please select any option";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// holidays 
function holidays() {
	
	let message = document.getElementById("holidays");
	let error = document.getElementById("holidaysError");
	if (message.value == "") {
		error.innerHTML = "Input is required !";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// availability
function availability() {
	let error = document.getElementById("availabilityError");
	if (document.getElementsByName("availability1").checked) { //Required Validation
		error.innerHTML = "Please select an option !";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}

//lastname validation
function validateLastName() {
	let message = document.getElementById("lastName");
	let error = document.getElementById("lastNameError");
	if (message.value == "") {
		error.innerHTML = "Last Name is required";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}


//validating gender
function validateGender() {
	if (
		document.getElementById("male").checked == true ||
		document.getElementById("female").checked == true ||
		document.getElementById("other").checked == true
	) {
		document.getElementById("genderError").innerHTML = "";
		return true;
	} else {
		document.getElementById("genderError").innerHTML =
			"Please select any one option";
		return false;
	}
}
// drop down
function validateJob1() {
	
	//let error = document.getElementById("jobError");
	if (document.getElementById("job").value == "select") {
		document.getElementById("jobError").innerHTML = "Please select any option";
		return false;
	} else {
		document.getElementById("jobError").innerHTML = "";
		return true;
	}
}
// Alternate

function Alternate() {
	
	let message = document.getElementById("Alternate");
	let error = document.getElementById("AlternateError");
	if (message.value == "") {
		error.innerHTML = "Input is required !";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
// Responsible
function responsible() {
	
	let message = document.getElementById("Responsible");
	let error = document.getElementById("ResponsibleError");
	if (message.value == "") {
		error.innerHTML = "Input is required !";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//
function Manager() {
	
	let message = document.getElementById("Manager");
	let error = document.getElementById("ManagerError");
	if (message.value == "") {
		error.innerHTML = "Input is required !";
		return false;
	} else {
		error.innerHTML = "";
		return true;
	}
}
//email validation
function validateEmail() {
	let message = document.getElementById("e-mail");
	let emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if (message.value != "") {     // Required Field Validation
		if (message.value.match(emailFormat)) {  // RegEx Validation
			document.getElementById("e-mailError").innerHTML = "";
			return true;
		} else {
			document.getElementById("e-mailError").innerHTML =
				"Enter in correct format";
			return false;
		}
	} else {
		document.getElementById("e-mailError").innerHTML = "Email ID is required";
		return false;
	}
}

function validateNumber() {
	let message = document.getElementById("mobileNumber");
	var regex = "/^[0-9]{10}$/";
    if (message.value != "") {// Required Field Validation
	if (message.value.length == 10 && message.value != regex) { 
		document.getElementById("mobileNumberError").innerHTML = "";
		return true;
	} else {
		document.getElementById("mobileNumberError").innerHTML =
			"Enter valid input";
		return false;
	}
}
else{
    document.getElementById("mobileNumberError").innerHTML = "Mobile Number  is required";
		return false;
}
}

//validating file
function validateFile() {
	let error = document.getElementById("fileError");

	
	if (document.getElementById("upload").value == "") {
		error.innerHTML = "Please select any file";
		return false;
	} else {
		

		let extn = document.getElementById("upload").value.split(".").pop();
		if (
			extn.toLowerCase() == "jpg" ||
			extn.toLowerCase() == "jpeg" ||
			extn.toLowerCase() == "png" ||
			extn.toLowerCase() == "pdf" ||
			extn.toLowerCase() == "doc" ||
			extn.toLowerCase() == "docx"
		) {
			error.innerHTML = "";
			return true;
		} else {
			error.innerHTML = "Upload a file with Valid format";
			return false;
		}
	}
}


function strToDate(datestr) {
	let dateArray = datestr.split("-");
	return new Date(dateArray[0], dateArray[1], dateArray[2]);
}

//joined date validation
function validateJoinedDate1() {

	if (document.getElementById("joinedDate").value == "") {
		document.getElementById("joinedDateError").innerHTML =
			"*From date is required";
		return false;
	}
	
	else if (document.getElementById("endDate").value != ""){
		let joinedDate = strToDate(document.getElementById("joinedDate").value);
		let endDate = strToDate(document.getElementById("endDate").value);

		
		if (endDate < joinedDate) {
			document.getElementById("joinedDateError").innerHTML =
				"*From date must be less than the End date";
		} else {
			document.getElementById("joinedDateError").innerHTML = "";
			return true;
		}
	}
	
	else {
		document.getElementById("joinedDateError").innerHTML = "";
		return true;
	}
}

//to date validation End date 
function validateEndDate() {
	
	if (document.getElementById("endDate").value == "") {
		document.getElementById("endDateError").innerHTML = "*To date is required !";
		return false;
	}
	
	else if (document.getElementById("joinedDate").value != "") {
		let joinedDate = strToDate(document.getElementById("joinedDate").value);
		let endDate = strToDate(document.getElementById("endDate").value);

		
		if (endDate < joinedDate) {
			document.getElementById("endDateError").innerHTML =
				"*To date must be greater than the Joined date !";
		} else {
			document.getElementById("endDateError").innerHTML = "";
			return true;
		}
	}
	
	else {
		document.getElementById("endDateError").innerHTML = "";
		return true;
	}
}

//validating verification Checkbox
function verification() {
	let error = document.getElementById("verificationError");
	if (document.getElementById("verification").checked) { //Required Validation
		error.innerHTML = "";
		return true;
	} else {
		error.innerHTML = "Please select ";
		return false;
	}
}
//Job validation
// function validateJob() {
// 	let error = document.getElementById("jobError");
// 	if (document.getElementById("jobPosition").value == "select") {
// 		error.innerHTML = "Please select any option";
// 		return false;
// 	} else {
// 		error.innerHTML = "";
// 		return true;
// 	}
// }

//validating all fields to show error messages during submit
function validateForm() {
    
	var errorCount = 0;
	if (!validateJob1()) {
		errorCount++;
	}

	if (!workdays()) {
		errorCount++;
	}
	if (!lead()) {
		errorCount++;
	}
	if (!leave()) {
		errorCount++;
	}
	if (!holidays()) {
		errorCount++;
	}
	if (!availability()) {
		errorCount++;
	}

	// if (!validateJob()) {
	// 	errorCount++;
	// }
	if (!validateJoinedDate1()) {
		errorCount++;
	}
	if (!Alternate()) {
		errorCount++;
	}
	if (!responsible()) {
		errorCount++;
	}
    if (!validateEndDate()) {
		errorCount++;
	}
    if (!Manager()) {
		errorCount++;
	}
	if (errorCount > 0) { 
		return false;
	}
	return true;
}
//Submit action for Update and Save operation
//Function to read the candidate information from the form and return the candidate as Json object
function readCandidateInfo() {
    
	let validateJob = document.getElementById("job").value;
    let leave = document.getElementById("leave").value;
	let work = document.getElementById("work").value;
	let lead = document.getElementById("lead").value;

	let holidays = document.getElementById("holidays").value;
	//let availability = document.getElementsByName("availability").value;
	let validateJoinedDate = document.getElementById("joinedDate").value;
	let Alternate = document.getElementById("Alternate").value;
	let responsible = document.getElementById("Responsible").value;
	let gender = "";
	let availability="";
	let validateEndDate = document.getElementById("endDate").value;
	let Manager = document.getElementById("Manager").value;

	let genderElements = document.getElementsByName("gender");

	for (var i = 0; i < genderElements.length; i++) {
		if (genderElements[i].checked) {
			gender = genderElements[i].nextElementSibling.innerText;
		}
	}
	let availabilityElement=  document.getElementsByName("availability");
	for (var i = 0; i < availabilityElement.length; i++) {
		if (availabilityElement[i].checked) {
			availability = availabilityElement[i].nextElementSibling.innerText;
		}
	}
	
	var candidateInfo = {
		Id: candidates.length + 1,
		validateJob: validateJob,
        leave:leave,
		lead: lead,
		work:work,
		holidays: holidays,
		availability: availability,
		validateJoinedDate: validateJoinedDate,
		Alternate: Alternate,
		responsible: responsible,
        gender:gender,
		validateEndDate: validateEndDate,
		Manager: Manager,
		//comments: comments,
		//filePath: filepath,
	};

	return candidateInfo;
}

//Function that manages entry into the Global var
function storeCandidateInfo() {
    // push the obj into an array
	candidates.push(readCandidateInfo());
}
function submitForm() {
	
	document.getElementById("comment12").style.display="none";
	 document.getElementById("btn").style.display="none";
	if (validateForm()) { // check the validation 1)
		
		if (document.getElementById("submitbtn").innerHTML.toLocaleLowerCase() == "update") {
			let candidateinfo = readCandidateInfo();
			let candidateindex = candidates.findIndex(
				(candidate) => candidate.Id == candidateId
			);

			candidates[candidateindex].validateJob = candidateinfo.validateJob;
			candidates[candidateindex].lead = candidateinfo.lead;
            candidates[candidateindex].leave = candidateinfo.leave;
			candidates[candidateindex].work = candidateinfo.work;
			candidates[candidateindex].holidays = candidateinfo.holidays;
			candidates[candidateindex].availability = candidateinfo.availability;
			candidates[candidateindex].validateJoinedDate = candidateinfo.validateJoinedDate;
			candidates[candidateindex].Alternate = candidateinfo.Alternate;
			candidates[candidateindex].responsible = candidateinfo.responsible;
			candidates[candidateindex].gender = candidateinfo.gender;
			candidates[candidateindex].validateEndDate = candidateinfo.validateEndDate;
			candidates[candidateindex].Manager = candidateinfo.Manager;
            // candidates[candidateindex].comments = candidateinfo.comments;
			candidates[candidateindex].filePath = candidateinfo.filePath;
		}
		//Save action 
		else {
			storeCandidateInfo(); // 2)
		}
		generateGrid(); //3)
		clearForm();// 4)
		showGrid();//5)
	}
}
function generateGrid() {
    
	//Clear the table body before forming the table structure
	document.getElementById("tableBody").innerText = "";
	for (var i = 0; i < candidates.length; i++) {
		// Create the dynamic tr,td and append every td in tr and tr in tbody
		let trow = document.createElement("tr");
		trow.className = "color";
		let id = document.createElement("td");
		id.className = "table";

		let validateJob = document.createElement("td");
		validateJob.className = "table";
        let leave = document.createElement("td");
		leave.className = "table";
		let lead = document.createElement("td");
		lead.className = "table";
		let work = document.createElement("td");
		work.className = "table";
		let holidays = document.createElement("td");
		holidays.className = "table";
		let availability = document.createElement("td");
		availability.className = "table";
		let validateJoinedDate = document.createElement("td");
		validateJoinedDate.className = "table";
		let Alternate = document.createElement("td");
		Alternate.className = "table";
		let responsible = document.createElement("td");
		responsible.className = "table";
		let gender = document.createElement("td");
		gender.className = "table";
		let validateEndDate = document.createElement("td");
		validateEndDate.className = "table";
        let Manager = document.createElement("td");
		Manager.className = "table";
		let filePath = document.createElement("td");
		filePath.className = "table";
        let edit = document.createElement("td");
		edit.className = "table";
        let deleteData = document.createElement("td");
		deleteData.className = "table";

		// append the values in each field resp.
		id.innerHTML = candidates[i].Id;
		validateJob.innerHTML = candidates[i].validateJob;
        leave.innerHTML = candidates[i].leave;
		lead.innerHTML = candidates[i].lead;
		work.innerHTML = candidates[i].work;
		holidays.innerHTML = candidates[i].holidays;
	    availability.innerHTML = candidates[i].availability;///////////////////////////////////////L
		validateJoinedDate.innerHTML = candidates[i].validateJoinedDate;
		Alternate.innerHTML = candidates[i].Alternate;
		responsible.innerHTML = candidates[i].responsible;
       // gender.innerHTML = candidates[i].gender;
        validateEndDate.innerHTML = candidates[i].validateEndDate;
        Manager.innerHTML = candidates[i].Manager;
      //  filePath.innerHTML = candidates[i].filePath;
		edit.innerHTML = "<a onclick='editForm(this)'>Edit</a>";
		deleteData.innerHTML = "<a onclick='deleteCandidate(this)'>Delete</a>";

		trow.appendChild(id); // append the td in tr
		trow.appendChild(validateJob);
        trow.appendChild(leave);
		trow.appendChild(lead);
		trow.appendChild(work);
		trow.appendChild(holidays);
		trow.appendChild(availability);
		trow.appendChild(validateJoinedDate);
		trow.appendChild(Alternate);
		trow.appendChild(responsible);
		//trow.appendChild(gender);
		trow.appendChild(validateEndDate);
        trow.appendChild(Manager);
        trow.appendChild(filePath);
        trow.appendChild(edit);
        trow.appendChild(deleteData);

		//appending tr in tbody
		document.getElementById("tableBody").appendChild(trow);
	}
}
function showForm() {
    document.getElementById("formToGrid").style.display = "block";
    document.getElementById("gridToForm").style.display = "none";
}
function showGrid() {
    document.getElementById("formToGrid").style.display = "none";
    document.getElementById("gridToForm").style.display = "block";
}
//Prepare the form for adding a new customer
function addCandidate() {
	clearForm(); // to clear the form
	document.getElementById("submitbtn").innerHTML = "Submit";
	document.getElementById("comment12").style.display="block";
	 document.getElementById("btn").style.display="block";
	showForm(); // to show the form to user

}

//clearing all fields
function clearForm() {
	
    
	document.getElementById("job").value = "";
	document.getElementById("work").value = "";
	document.getElementById("lead").value = "";
	// document.getElementById("male").checked = false;
	// document.getElementById("female").checked = false;
	// document.getElementById("other").checked = false;
	document.getElementById("leave").value = "";
	document.getElementById("holidays").value = "";
	document.getElementById("joinedDate").value = "";
	document.getElementById("Alternate").value = "";
	document.getElementById("Responsible").value = "";
	document.getElementById("endDate").value = "";
	document.getElementById("Manager").value = "";
	document.getElementsByName("availability").value = "";

	//clearing error messages
    document.getElementById("jobError").innerHTML = "";
	document.getElementById("workError").innerHTML = "";
	document.getElementById("leadError").innerHTML = "";
	document.getElementById("leaveError").innerHTML = "";
	document.getElementById("holidaysError").innerHTML = "";
	document.getElementsByName("availabilityError").innerHTML = "";
	document.getElementById("joinedDateError").innerHTML = "";
	document.getElementById("AlternateError").innerHTML = "";
	document.getElementById("ResponsibleError").innerHTML = "";
	document.getElementById("endDateError").innerHTML = "";
	document.getElementById("ManagerError").innerHTML = "";
	
}

function editForm(obj) {
	debugger
	var edit = obj.closest("tr");
	candidateId = parseInt(edit.cells[0].innerText);
	let candidate = findCandidate(candidateId);
	prefillForm(candidate);
	document.getElementById("submitbtn").innerHTML = "Update";
	showForm(); //form is displayed
}
//Find candidate based on the id
function findCandidate(candidateId) {
	return candidates.find((candidate) => candidate.Id == candidateId);
}

function prefillForm(candidateInfo) {
	debugger
	document.getElementById("job").value = candidateInfo.job;
	document.getElementById("work").value = candidateInfo.work;
	document.getElementById("lead").value = candidateInfo.lead;

	// switch (candidateInfo.gender.toLowerCase()) {
	// 	case "male":
	// 		document.getElementById("male").checked = true;
	// 		break;
	// 	case "female":
	// 		document.getElementById("female").checked = true;
	// 		break;
	// }

	document.getElementById("leave").value = candidateInfo.leave;
	document.getElementsByName("availability").value = candidateInfo.availability;
	document.getElementById("holidays").value = candidateInfo.holidays;
	document.getElementById("joinedDate").value = candidateInfo.validateJoinedDate;
	document.getElementById("Alternate").value = candidateInfo.Alternate;
	document.getElementById("Responsible").value = candidateInfo.responsible;
	document.getElementById("endDate").value = candidateInfo.validateEndDate;
	document.getElementById("Manager").value = candidateInfo.Manager;
}
function deleteCandidate(candidateobj) {// candidateobj get click td 
    var deleterow = candidateobj.closest("tr"); // closet get the nearest elements data td na hole tr data va get panna
    let delcandidateId = parseInt(deleterow.cells[0].innerText); // cell[0] get the tr id 
    if (confirm("Are you sure you want to delete this Candidate?")) {
         let candidateindex = candidates.findIndex(candidate => candidate.Id == delcandidateId);// compaer the original data and selected data is eqal to confirm that date is present
		//let candidateindex = delcandidateId-1;

        candidates.splice(candidateindex, 1);
        candidates.forEach((candidate, index) => {
            candidate.Id = index + 1; // change id dynamically using the index to increse +1 and
			// automatically the id will be hytrate and arange in order..
        });
    }
    generateGrid();//Forming the Grid
}